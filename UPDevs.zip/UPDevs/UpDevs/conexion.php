<?php
$conexion=pg_connect("host=localhost 
dbname=desarrolloUpdevs
user=postgres   
password=1234");
if($conexion){
    echo "CONECTÓ";
}else{
    
    echo "no CONECTÓ";
}
$query="SELECT * from cliente";
$consulta=pg_query($conexion,$query);
echo "<p>entro a la conexion<br>";
/*if(pg_num_rows($consulta)>0){
    echo "<p>personas en la base de datos<br>";
    echo "---------------------------------</p>";
    while($obj=pg_fetch_object($consulta)){
        echo $obj->cedula."<br>";
        echo $obj->nombre."<br>";
        echo $obj->apellido."<br>";
        echo $obj->email."<br>";
    }
}*/

//obtenemos los valores del formulario
$nombre = $_POST['name'];
$email = $_POST['email'];
$telefono = $_POST['phone'];
$mensaje = $_POST['message'];


//Obtiene la longitus de un string
$req = (strlen($nombre)*strlen($email)*strlen($telefono)*strlen($mensaje)) or die("No se han llenado todos los campos");

$query=("SELECT * FROM cliente WHERE telefono='$telefono'");
$consulta=pg_query($conn,$query) or die ('Hubo un error en la consulta.').pg_last_error();
if(pg_num_rows($consulta)>0){
    echo "<p>LA PERSONA ESTA EN LA BASE DE DATOS<br>";
}else{
    echo "<p>LA PERSONA noooooo ESTA EN LA BASE DE DATOS<br>";
}

?>