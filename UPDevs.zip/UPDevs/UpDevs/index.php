<?php require_once('conexion.php');?>
<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Libre+Franklin:200,300,500,600,300italic">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <!--Page-->
    <div class="page">
      <div id="page-loader">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
      </div>
    <!--Page Header-->
      <header class="page-header">
        <!--RD Navbar-->
        <div class="rd-navbar-wrap">
          <nav class="rd-navbar" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-sm-device-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-fixed" data-xl-device-layout="rd-navbar-static" data-xxl-device-layout="rd-navbar-static" data-lg-layout="rd-navbar-fixed" data-xl-layout="rd-navbar-static" data-xxl-layout="rd-navbar-static" data-stick-up-clone="false" data-sm-stick-up="true" data-md-stick-up="true" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true" data-lg-stick-up-offset="69px" data-xl-stick-up-offset="1px" data-xxl-stick-up-offset="1px">
            <div class="rd-navbar-inner">
              <!--RD Navbar Panel-->
              <div class="rd-navbar-panel">
                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                <!--RD Navbar Brand-->
                <div class="rd-navbar-brand"><a class="brand-name" href="index.html"><img src="images/logo-updevs.png" alt="" width="200" height="32"/></a></div>
              </div>
              <!--RD Navbar Nav-->
              <div class="rd-navbar-nav-wrap">
                <ul class="rd-navbar-nav">
                  <li class="active"><a href="index.html">Inicio</a></li>
                  <li><a href="about.html">¿Quienes Somos?</a></li>
                  <li><a href="typography.html">Productos</a></li>
                  <li><a href="contacts.html">Contactenos</a></li>
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </header>
      <!--Swiper-->
      <section>
        <div class="swiper-container swiper-slider swiper-slider_fullheight" data-simulate-touch="false" data-loop="false" data-autoplay="false">
          <div class="swiper-wrapper">
            <div class="swiper-slide swiper-slide_video context-dark video-bg-overlay">
                    <!--RD Video-->
                    <div class="vide_bg" data-vide-bg="video/video-lg" data-vide-options="posterType: jpg">
                      <div class="swiper-slide-caption text-center">
                        <div class="container">
                          <h2 data-caption-animate="fadeInUpSmall">SISTEMAS HECHOS A TU MEDIDA</h2>
                          <h5 class="text-width-2 block-centered" data-caption-animate="fadeInUpSmall" data-caption-delay="200">Nuestros productos garantizan crecimiento e innovacion para tu empresa.</h5>
                          <div class="group-lg group-middle"><a class="button button-black" data-caption-animate="fadeInUpSmall" data-caption-delay="350" href="#section-see-features" data-custom-scroll-to="section-see-features">Caracteristicas</a><a class="button button-primary" data-caption-animate="fadeInUpSmall" data-caption-delay="350" data-custom-scroll-to="section-subscribe" href="#section-subscribe">Suscribete</a></div>
                        </div>
                      </div>
                    </div>
            </div>
            <div class="swiper-slide bg-gray-lighter" data-slide-bg="images/img1.jpg">
              <div class="swiper-slide-caption text-center">
                <div class="container">
                  <h1 data-caption-animate="fadeInUpSmall"><span>UpDevs</span></h1>
                  <h3 data-caption-animate="fadeInUpSmall" data-caption-delay="200">Diseñamos, Modificamos, Personalizams Y creamos los mejores softwares de la ciudad</h3>
                  <div class="group-lg group-middle"><a class="button button-primary" data-caption-animate="fadeInUpSmall" data-caption-delay="350" href="#section-see-features" data-custom-scroll-to="section-see-features">Caracteristicas</a><a class="button button-black" data-caption-animate="fadeInUpSmall" data-caption-delay="350" data-custom-scroll-to="section-subscribe" href="#section-subscribe">Suscribete</a></div>
                </div>
              </div>
            </div>
            <div class="swiper-slide swiper-slide_top bg-accent" data-slide-bg="images/img2.png">
              <div class="swiper-slide-caption">
                <div class="container">
                  <h3 data-caption-animate="fadeInLeftSmall">Trabajamos con diferentes lenguajes de programacion,<br class="d-none d-lg-block"> a tu gusto y tu criterio ²</h3><a class="button button-black" data-caption-animate="fadeInUpSmall" data-caption-delay="200" data-custom-scroll-to="section-subscribe" href="#section-subscribe">Suscribete</a>
                </div>
              </div>
            </div>
          </div>
          <!--Swiper Pagination-->
          <div class="swiper-pagination"></div>
          <!--Swiper Navigation-->
          <div class="swiper-button-prev linear-icon-chevron-left"></div>
          <div class="swiper-button-next linear-icon-chevron-right"></div>
        </div>
      </section>
      <!--Presentation-->
      <section class="section-xl bg-default text-center" id="section-see-features">
        <div class="container">
          <div class="row justify-content-lg-center">
            <div class="col-lg-10 col-xl-8">
              <h3>NUESTRAS CARACTERISTICAS</h3>
              <p>UpDevs se caracteriza por tener los mejores Software, aplicativos, video juegos, y paginas web de manera responsive, didacticas, entendibles de calidad, con un cresimiento continuo y constante y mejoras y actualizaciones continuas en nuestra variedad de servicios.</p>
            </div>
          </div>
        </div>
      </section>
      <!--The Power of Bootstrap Toolkit-->
      <section class="bg-gray-lighter object-wrap">
        <div class="section-xxl section-xxl_bigger">
          <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <h3>DESARROLLO DE VIDEO JUEGOS</h3>
                    <p>Creemos en el poder del entretenimiento. Cómo sus maravillas tienen la posibilidad de hacerte sonreír y abrir los ojos.</p>
                    <p>Creemos que los juegos tienen la posibilidad de permitirte hacer cosas extraordinarias. Te traen este instante puro de escapismo que sencillamente te hace feliz.</p>
                </div>
            </div>
          </div>
        </div>
        <div class="object-wrap__body object-wrap__body-sizing-1 object-wrap__body-md-right bg-image" style="background-image: url(images/foto2.jpeg)"></div>
      </section>
      <!--Content Driven Design-->
      <section class="section-xl bg-default">
        <div class="container">
          <div class="row justify-content-md-center flex-lg-row-reverse align-items-lg-center justify-content-lg-between row-50">
            <div class="col-md-9 col-lg-5">
              <h3>DESARROLLO DE APLICATIVOS</h3>
              <p>El desarrollo de aplicativos es una nueva forma de emprender genera numerosos ingresos y aporta nuevos conocimientos para el publico en general y en UpDevs encontraras un amplio portafolio </p>
            </div>
            <div class="col-md-9 col-lg-6"><img src="images/foto43.jpeg" alt="" width="652" height="491"/>
            </div>
          </div>
        </div>
      </section>
      <!--Blurbs-->
      <section class="section-xl bg-gray-lighter">
        <div class="container">
          <div class="row row-50">
            <div class="col-md-6 col-lg-4">
              <!--Blurb minimal-->
              <article class="blurb blurb-minimal">
                <div class="unit flex-row unit-spacing-md">
                  <div class="unit-left">
                    <div class="blurb-minimal__icon"><span class="icon linear-icon-magic-wand"></span></div>
                  </div>
                  <div class="unit-body">
                    <p class="blurb__title">Diseños perfectos</p>
                    <p>El diseño es lo primero que vemos en un aplicativo, pagina o video juego ya que todo entra por los ojos es por eso que UpDevs ofrece los mejores diseños quen provocan confianza en los usuarios y ayudará a la hora de decidir si adquieren un producto o servicio.</p>
                  </div>
                </div>
              </article>
            </div>
            <div class="col-md-6 col-lg-4">
              <!--Blurb minimal-->
              <article class="blurb blurb-minimal">
                <div class="unit flex-row unit-spacing-md">
                  <div class="unit-left">
                    <div class="blurb-minimal__icon"><span class="icon linear-icon-menu3"></span></div>
                  </div>
                  <div class="unit-body">
                    <p class="blurb__title">Ecxelente para cualquier dispositivo</p>
                    <p> Nuestros productos estan diseñados de manera receptiva ya que se adaptan a cualquier dispositivo ya sea un celula, tableta o computador tambien tenemos una excepcion en los video juegos ya que se desarrolan dependiendo del gusto del cliente ya sea para Pc o telefono.</p>
                  </div>
                </div>
              </article>
            </div>
            <div class="col-md-6 col-lg-4">
              <!--Blurb minimal-->
              <article class="blurb blurb-minimal">
                <div class="unit flex-row unit-spacing-md">
                  <div class="unit-left">
                    <div class="blurb-minimal__icon"><span class="icon linear-icon-users2"></span></div>
                  </div>
                  <div class="unit-body">
                    <p class="blurb__title">Hecho para personas</p>
                    <p>En UpDevs trabajamos con base a un arquetipo específico que se verá representado para posteriormente satisfacer un amplio grupo de usuarios o consumidores afines.</p>
                  </div>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>
      <!--GPL3 License advantages-->
      <section class="section-xl bg-default">
        <div class="container">
          <div class="row row-50 align-items-lg-center justify-content-lg-between">
            <div class="col-lg-5">
              <h3>DESARROLLO DE PAGINAS WEB</h3>
              <p>UpDevs tiene un portafolio amplio de diferentes diseños y plantillas de paginas web creadas y diseñadas de manera responsiva con diseños llamativos que llamen la atencion al consumidor.</p>
            </div>
            <div class="col-lg-6">
              <div class="row gallery-wrap">
                <div class="col-6"><img src="images/foto42.jpeg" alt="" width="301" height="227"/>
                </div>
                <div class="col-6"><img src="images/foto40.jpeg" alt="" width="301" height="227"/>
                </div>
                <div class="col-6"><img src="images/foto38.jpeg" alt="" width="301" height="227"/>
                </div>
                <div class="col-6"><img src="images/foto27.jpeg" alt="" width="301" height="227"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="bg-gray-dark text-center">
              <!--RD Parallax-->
              <div class="parallax-container bg-image rd-parallax-light" data-parallax-img="images/img3.jpg">
                <div class="parallax-content">
                  <div class="container section-xxl">
                    <h2>¿Te gusta lo que ofrecemos?</h2>
                    <p>Si quieres saber mas consulta nuestro portafolio en la seccion de productos.</p><a class="button button-primary" href="Productos.html">Ver ahora!</a>
                  </div>
                </div>
              </div>
      </section>
      <section class="section-xl bg-default text-center">
        <div class="container">
          <div class="row row-30 justify-content-lg-center">
            <div class="col-lg-11 col-xl-9">
              <h3>NUESTRO EQUIPO DE TRABAJO</h3>
               </div>
          </div>
          <div class="row row-50 offset-top-1">
              <div class="col-md-5 col-lg-2">
                  <!--Thumb corporate-->
                  <div class="thumb thumb-corporate">
                      <div class="thumb-corporate__main">
                          <img src="images/perfil1.jpeg" alt="" width="200" height="200" />
                          <div class="thumb-corporate__overlay">
                              <ul class="list-inline-sm thumb-corporate__list">
                                  <li><a class="icon icon-sm fa-facebook" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-twitter" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-google-plus" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-vimeo" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-youtube" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-pinterest-p" href="#"></a></li>
                              </ul>
                          </div>
                      </div>
                      <div class="thumb-corporate__caption">
                          <p class="thumb__title"><a href="#">Brian King</a></p>
                          <p class="thumb__subtitle">Director</p>
                      </div>
                  </div>
              </div>
              <div class="col-md-5 col-lg-3">
                  <!--Thumb corporate-->
                  <div class="thumb thumb-corporate">
                      <div class="thumb-corporate__main">
                          <img src="images/perfil3.jpeg" alt="" width="200" height="200" />
                          <div class="thumb-corporate__overlay">
                              <ul class="list-inline-sm thumb-corporate__list">
                                  <li><a class="icon icon-sm fa-facebook" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-twitter" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-google-plus" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-vimeo" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-youtube" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-pinterest-p" href="#"></a></li>
                              </ul>
                          </div>
                      </div>
                      <div class="thumb-corporate__caption">
                          <p class="thumb__title"><a href="#">Brian King</a></p>
                          <p class="thumb__subtitle">Director</p>
                      </div>
                  </div>
              </div>
              <div class="col-md-5 col-lg-3">
                  <!--Thumb corporate-->
                  <div class="thumb thumb-corporate">
                      <div class="thumb-corporate__main">
                          <img src="images/perfil4.jpeg" alt="" width="200" height="200" />
                          <div class="thumb-corporate__overlay">
                              <ul class="list-inline-sm thumb-corporate__list">
                                  <li><a class="icon icon-sm fa-facebook" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-twitter" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-google-plus" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-vimeo" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-youtube" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-pinterest-p" href="#"></a></li>
                              </ul>
                          </div>
                      </div>
                      <div class="thumb-corporate__caption">
                          <p class="thumb__title"><a href="#">Amanda Smith</a></p>
                          <p class="thumb__subtitle">Marketing manager</p>
                      </div>
                  </div>
              </div>
              <div class="col-md-5 col-lg-3">
                  <!--Thumb corporate-->
                  <div class="thumb thumb-corporate">
                      <div class="thumb-corporate__main">
                          <img src="images/perfil2.jpeg" alt="" width="200" height="200" />
                          <div class="thumb-corporate__overlay">
                              <ul class="list-inline-sm thumb-corporate__list">
                                  <li><a class="icon icon-sm fa-facebook" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-twitter" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-google-plus" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-vimeo" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-youtube" href="#"></a></li>
                                  <li><a class="icon icon-sm fa-pinterest-p" href="#"></a></li>
                              </ul>
                          </div>
                      </div>
                      <div class="thumb-corporate__caption">
                          <p class="thumb__title"><a href="#">George Nelson</a></p>
                          <p class="thumb__subtitle">Designer</p>
                      </div>
                  </div>
              </div>
          </div>
        </div>
      </section>
      <!--Gallery-->
      <section class="section-xl bg-default" data-lightgallery="group">
        <div class="container-fluid">
          <div class="row row-10 row-horizontal-10">
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/image-original-1-1200x905.jpg">
                <figure><img src="images/home-default-7-472x355.jpg" alt="" width="472" height="355"/>
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/image-original-2-1200x905.jpg">
                <figure><img src="images/home-default-8-472x355.jpg" alt="" width="472" height="355"/>
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/image-original-3-1200x906.jpg">
                <figure><img src="images/home-default-9-472x355.jpg" alt="" width="472" height="355"/>
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/image-original-4-1200x905.jpg">
                <figure><img src="images/home-default-10-472x355.jpg" alt="" width="472" height="355"/>
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/image-original-5-1200x905.jpg">
                <figure><img src="images/home-default-11-472x355.jpg" alt="" width="472" height="355"/>
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/image-original-6-1200x905.jpg">
                <figure><img src="images/home-default-12-472x355.jpg" alt="" width="472" height="355"/>
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/image-original-7-1200x906.jpg">
                <figure><img src="images/home-default-13-472x355.jpg" alt="" width="472" height="355"/>
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
            <div class="col-md-4 col-xl-3"><a class="thumb-modern" data-lightgallery="item" href="images/image-original-8-1200x906.jpg">
                <figure><img src="images/home-default-14-472x355.jpg" alt="" width="472" height="355"/>
                </figure>
                <div class="thumb-modern__overlay"></div></a></div>
          </div>
        </div>
      </section>
      <!--Share Your Company Testimonials-->
      <section class="section-lg bg-gray-lighter text-center">
        <div class="container">
          <h3>Share Your Company Testimonials</h3>
          <!--Owl Carousel-->
          <div class="owl-carousel owl-carousel-spacing-1" data-autoplay="true" data-items="1" data-stage-padding="15" data-loop="true" data-margin="30" data-nav="true">
            <div class="item">
              <!--Quote default-->
              <div class="quote-default">
                <svg class="quote-default__mark" version="1.1" baseprofile="tiny" x="0px" y="0px" width="30.234px" height="23.484px" viewbox="0 0 30.234 23.484">
                  <g>
                    <path d="M12.129,0v1.723c-2.438,0.891-4.348,2.291-5.73,4.201c-1.383,1.911-2.074,3.897-2.074,5.959 c0,0.445,0.07,0.773,0.211,0.984c0.093,0.141,0.199,0.211,0.316,0.211c0.117,0,0.293-0.082,0.527-0.246 c0.75-0.539,1.699-0.809,2.848-0.809c1.336,0,2.519,0.545,3.551,1.635c1.031,1.09,1.547,2.385,1.547,3.885 c0,1.57-0.592,2.953-1.775,4.148c-1.184,1.195-2.619,1.793-4.307,1.793c-1.969,0-3.668-0.809-5.098-2.426 C0.715,19.441,0,17.274,0,14.555c0-3.164,0.972-6,2.918-8.508C4.863,3.539,7.933,1.524,12.129,0z M29.039,0v1.723 c-2.438,0.891-4.348,2.291-5.73,4.201c-1.383,1.911-2.074,3.897-2.074,5.959c0,0.445,0.07,0.773,0.211,0.984 c0.094,0.141,0.199,0.211,0.316,0.211s0.293-0.082,0.527-0.246c0.75-0.539,1.699-0.809,2.848-0.809c1.336,0,2.52,0.545,3.551,1.635 s1.547,2.385,1.547,3.885c0,1.57-0.592,2.953-1.775,4.148s-2.619,1.793-4.307,1.793c-1.969,0-3.668-0.809-5.098-2.426 s-2.145-3.785-2.145-6.504c0-3.164,0.973-6,2.918-8.508C21.773,3.539,24.844,1.524,29.039,0z"></path>
                  </g>
                </svg>
                <div class="quote-default__text">
                  <p class="q">I love to use your ready-made and beautifully looking templates. They are available at very affordable prices and they save me a lot of time, and deliver from a lot of sweat and tears!</p>
                </div>
                <p class="quote-default__cite">Jane Smith</p>
              </div>
            </div>
            <div class="item">
              <!--Quote default-->
              <div class="quote-default">
                <svg class="quote-default__mark" version="1.1" baseprofile="tiny" x="0px" y="0px" width="30.234px" height="23.484px" viewbox="0 0 30.234 23.484">
                  <g>
                    <path d="M12.129,0v1.723c-2.438,0.891-4.348,2.291-5.73,4.201c-1.383,1.911-2.074,3.897-2.074,5.959 c0,0.445,0.07,0.773,0.211,0.984c0.093,0.141,0.199,0.211,0.316,0.211c0.117,0,0.293-0.082,0.527-0.246 c0.75-0.539,1.699-0.809,2.848-0.809c1.336,0,2.519,0.545,3.551,1.635c1.031,1.09,1.547,2.385,1.547,3.885 c0,1.57-0.592,2.953-1.775,4.148c-1.184,1.195-2.619,1.793-4.307,1.793c-1.969,0-3.668-0.809-5.098-2.426 C0.715,19.441,0,17.274,0,14.555c0-3.164,0.972-6,2.918-8.508C4.863,3.539,7.933,1.524,12.129,0z M29.039,0v1.723 c-2.438,0.891-4.348,2.291-5.73,4.201c-1.383,1.911-2.074,3.897-2.074,5.959c0,0.445,0.07,0.773,0.211,0.984 c0.094,0.141,0.199,0.211,0.316,0.211s0.293-0.082,0.527-0.246c0.75-0.539,1.699-0.809,2.848-0.809c1.336,0,2.52,0.545,3.551,1.635 s1.547,2.385,1.547,3.885c0,1.57-0.592,2.953-1.775,4.148s-2.619,1.793-4.307,1.793c-1.969,0-3.668-0.809-5.098-2.426 s-2.145-3.785-2.145-6.504c0-3.164,0.973-6,2.918-8.508C21.773,3.539,24.844,1.524,29.039,0z"></path>
                  </g>
                </svg>
                <div class="quote-default__text">
                  <p class="q">This template has everything I was looking for my business website to have. From easy-to-customize pages to flawlessly working web tools, Monstroid² is my number one choice!</p>
                </div>
                <p class="quote-default__cite">James Wilson</p>
              </div>
            </div>
            <div class="item">
              <!--Quote default-->
              <div class="quote-default">
                <svg class="quote-default__mark" version="1.1" baseprofile="tiny" x="0px" y="0px" width="30.234px" height="23.484px" viewbox="0 0 30.234 23.484">
                  <g>
                    <path d="M12.129,0v1.723c-2.438,0.891-4.348,2.291-5.73,4.201c-1.383,1.911-2.074,3.897-2.074,5.959 c0,0.445,0.07,0.773,0.211,0.984c0.093,0.141,0.199,0.211,0.316,0.211c0.117,0,0.293-0.082,0.527-0.246 c0.75-0.539,1.699-0.809,2.848-0.809c1.336,0,2.519,0.545,3.551,1.635c1.031,1.09,1.547,2.385,1.547,3.885 c0,1.57-0.592,2.953-1.775,4.148c-1.184,1.195-2.619,1.793-4.307,1.793c-1.969,0-3.668-0.809-5.098-2.426 C0.715,19.441,0,17.274,0,14.555c0-3.164,0.972-6,2.918-8.508C4.863,3.539,7.933,1.524,12.129,0z M29.039,0v1.723 c-2.438,0.891-4.348,2.291-5.73,4.201c-1.383,1.911-2.074,3.897-2.074,5.959c0,0.445,0.07,0.773,0.211,0.984 c0.094,0.141,0.199,0.211,0.316,0.211s0.293-0.082,0.527-0.246c0.75-0.539,1.699-0.809,2.848-0.809c1.336,0,2.52,0.545,3.551,1.635 s1.547,2.385,1.547,3.885c0,1.57-0.592,2.953-1.775,4.148s-2.619,1.793-4.307,1.793c-1.969,0-3.668-0.809-5.098-2.426 s-2.145-3.785-2.145-6.504c0-3.164,0.973-6,2.918-8.508C21.773,3.539,24.844,1.524,29.039,0z"></path>
                  </g>
                </svg>
                <div class="quote-default__text">
                  <p class="q">It’s great that there are such templates that are available to both professional and beginner web developers at affordable price. The job you did with this template is surely appreciated, thank you!</p>
                </div>
                <p class="quote-default__cite">Sam Lee</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="bg-accent">
        <div class="container">
          <div class="row justify-content-md-center align-items-lg-end">
            <div class="col-md-8 col-lg-6 section-xl">
              <h3>Haven’t Found What You Like? Browse Our Other Demos</h3>
              <p>Monstroid² has everything to get you covered. Take a look at the child themes included with the full template version. They cover most popular spheres of interest including Art & Photography, Business, Education and Design.</p><a class="button button-gray-light-outline" href="#">View now!</a>
            </div>
            <div class="col-md-8 col-lg-6">
              <div class="cat-img-group">
                <div><img src="images/cat-2-507x508.jpg" alt="" width="507" height="508"/>
                </div>
                <div><img src="images/cat-1-326x427.jpg" alt="" width="326" height="427"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Subscribe form-->
      <section class="section-xl bg-default text-center" id="section-subscribe">
        <div class="container">
          <h5>Get latest news delivered daily! <br> We will send you breaking news right to your inbox.</h5>
          <!--RD Mailform-->
          
          <form class="rd-mailform rd-mailform_style-1 rd-mailform_sizing-1 rd-mailform-inline-flex text-center" data-form-output="form-output-global" data-form-type="subscribe" method="post" action="bat/rd-mailform.php">
            <div class="form-wrap form-wrap_icon linear-icon-envelope">
              <input class="form-input" id="contact-email" type="email" name="email" data-constraints="@Email @Required">
              <label class="form-label" for="contact-email">Enter please your e-mail</label>
            </div>
            <button class="button button-primary" type="submit">Subscribe!</button>
          </form>
        </div>
     
      <!--Page Footer-->
      <section class="pre-footer-corporate">
        <div class="container">
          <div class="row justify-content-sm-center justify-content-lg-start row-30 row-md-60">
            <div class="col-sm-10 col-md-6 col-lg-10 col-xl-3">
              <h6>About</h6>
              <p>Monstroid² is HTML template that fits for both developers and beginners. It comes loaded with an assortment of tools and features that make customization process much easier. A pack of child themes, provided with the full version of this template, allows users to create a fully functional site for any specific business quickly and worry-free.</p>
            </div>
            <div class="col-sm-10 col-md-6 col-lg-3 col-xl-3">
              <h6>Quick Links</h6>
              <ul class="list-xxs">
                <li><a href="#">Retina Homepage</a></li>
                <li><a href="#">New Page Examples</a></li>
                <li><a href="#">Parallax Sections</a></li>
                <li><a href="#">Shortcode Central</a></li>
                <li><a href="#">Ultimate Font Collection</a></li>
              </ul>
            </div>
            <div class="col-sm-10 col-md-6 col-lg-5 col-xl-3">
              <h6>Recent Comments</h6>
              <ul class="list-xs">
                <li>
                  <!--Comment minimal-->
                  <article class="comment-minimal">
                    <p class="comment-minimal__author">Brian Williamson on</p>
                    <p class="comment-minimal__link"><a href="#">Site Speed and Search Engines Optimization Aspects</a></p>
                  </article>
                </li>
                <li>
                  <!--Comment minimal-->
                  <article class="comment-minimal">
                    <p class="comment-minimal__author">Brian Williamson on</p>
                    <p class="comment-minimal__link"><a href="#">5 Things to Know Before You Buy an HTML Template</a></p>
                  </article>
                </li>
                <li>
                  <!--Comment minimal-->
                  <article class="comment-minimal">
                    <p class="comment-minimal__author">Brian Williamson on</p>
                    <p class="comment-minimal__link"><a href="#">Turning Your Site into a Sales Machine</a></p>
                  </article>
                </li>
              </ul>
            </div>
            <div class="col-sm-10 col-md-6 col-lg-4 col-xl-3">
              <h6>Contacts</h6>
              <ul class="list-xs">
                <li>
                  <dl class="list-terms-minimal">
                    <dt>Address</dt>
                    <dd>4578 Marmora Road, Glasgow, D04 89GR</dd>
                  </dl>
                </li>
                <li>
                  <dl class="list-terms-minimal">
                    <dt>Phones</dt>
                    <dd>
                      <ul class="list-semicolon">
                        <li><a href="tel:#">(800) 123-0045</a></li>
                        <li><a href="tel:#">(800) 123-0045</a></li>
                      </ul>
                    </dd>
                  </dl>
                </li>
                <li>
                  <dl class="list-terms-minimal">
                    <dt>E-mail</dt>
                    <dd><a href="mailto:#">info@demolink.org</a></dd>
                  </dl>
                </li>
                <li>
                  <dl class="list-terms-minimal">
                    <dt>We are open</dt>
                    <dd>Mn-Fr: 10 am-8 pm</dd>
                  </dl>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      <footer class="footer-corporate">
        <div class="container">
          <div class="footer-corporate__inner">
            <p class="rights">Monstroid&#178;&nbsp;&copy; <span class="copyright-year"></span>.
              Design&nbsp;by&nbsp;<a href="https://www.templatemonster.com">TemplateMonster</a>
            </p>
            <ul class="list-inline-xxs">
              <li><a class="icon icon-xxs icon-primary fa fa-facebook" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-twitter" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-google-plus" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-vimeo" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-youtube" href="#"></a></li>
              <li><a class="icon icon-xxs icon-primary fa fa-pinterest" href="#"></a></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
    <!--Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!--Javascript-->
    <script src="js/core.min.js" defer></script>
    <script src="js/script.js" defer></script>
    <!--coded by ATOM-->
  </body>
</html>